package testador;

import conexao.ConexaoMysql;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import coordenada.Coordenada;
import data.MemoryDataBankSolicitacao;
import data.MongoDao;
import data.MysqlDao;
import file.CoordenadaFile;
import file.Experimento;

public class Testador {

	public static void main(String[] args) {

               //Mongo
               Experimento ex = new Experimento();
               //ex.InserirMongo();
               ex.BuscarMongo(116.44433,39.92961);
               
               
              // MYSQL
              //ex.InserirMysql();
              //ex.BuscarMysql();
              
	}

}