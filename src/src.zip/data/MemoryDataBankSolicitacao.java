package data;

import java.util.ArrayList;
import java.util.List;

import coordenada.Coordenada;

public class MemoryDataBankSolicitacao implements IDao<Coordenada>{
    
    private List<Coordenada> MemoryDataBankSolicitacao = new ArrayList<>(); 

    @Override
    public void save(Coordenada t) {
        this.MemoryDataBankSolicitacao.add(t);
    }

    @Override
    public List<Coordenada> list() {
        return MemoryDataBankSolicitacao;
    }

    @Override
    public Coordenada getOne(double latitude, double longitude) {
        return null;
    }

  
   
}