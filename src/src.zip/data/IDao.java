package data;

import java.util.List;

public interface IDao <T>{
		
		void save(T t);
                				
		List<T> list();
	
                T getOne(double latitude, double longitude);
}