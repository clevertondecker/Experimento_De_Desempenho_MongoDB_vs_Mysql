package data;

import java.util.ArrayList;
import java.util.List;

import org.bson.BasicBSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import conexao.ConexaoMongo;
import coordenada.Coordenada;

public class MongoDao implements IDao<Coordenada> {

	ConexaoMongo conexao;
	
	public MongoDao(){
		this.conexao = new ConexaoMongo();
	}
	
	@Override
	public void save(Coordenada c) {
		BasicDBObject coordenada = new BasicDBObject();
		coordenada.put("latitude", c.getLatitude());
		coordenada.put("longitude", c.getLongitude());
	
		this.conexao.getCollection().insert(coordenada);
	}

	@Override
        public Coordenada getOne(double latitude, double longitude) {
		
                System.out.println(latitude + " " + longitude);
		BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("latitude", latitude);
		whereQuery.put("longitude", longitude);
		
		BasicDBObject document = (BasicDBObject) this.conexao.getCollection().findOne(whereQuery);
		
		Object latitude2 = document.get("latitude");
		Object longitude2 = document.get("longitude");
		
		String str1 = latitude2.toString();
		double lat1 = Double.valueOf(str1).doubleValue();
		
		String str2 = longitude2.toString();
		double lat2 = Double.valueOf(str2).doubleValue();
		
		Coordenada retorno = new Coordenada(lat1, lat2);
	    
	    return retorno; 

	}

	@Override
	public List<Coordenada> list() {
		
		List<Coordenada> coordenadas = new ArrayList<>();
		
		DBCursor listaDoCursor = this.conexao.getCollection().find();

		for (DBObject document : listaDoCursor) {
			
			Object latitude = document.get("latitude");
			Object longitude = document.get("longitude");
			
			String str1 = latitude.toString();
			double lat1 = Double.valueOf(str1).doubleValue();
			
			String str2 = longitude.toString();
			double lat2 = Double.valueOf(str2).doubleValue();
			
			coordenadas.add(new Coordenada(lat1,lat2));	
		}
		
	    return coordenadas;
	}

}
