package data;

import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;

import conexao.ConexaoMongo;
import conexao.ConexaoMysql;
import coordenada.Coordenada;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MysqlDao implements IDao<Coordenada> {

    Connection conexao;

    public MysqlDao(Connection conexao) {
        this.conexao = conexao;
    }

    @Override
    public void save(Coordenada c) {
        String SQL = "INSERT INTO coordenada (`latitude`, `longitude`) VALUES (?,?)";
        try {
            PreparedStatement pstmt = this.conexao.prepareStatement(SQL);
            pstmt.setDouble(1, c.getLatitude());
            pstmt.setDouble(2, c.getLongitude());
            pstmt.execute();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
         
    }

    @Override
    public List<Coordenada> list() {
        List<Coordenada> list = new ArrayList<>();
        Coordenada c;

        try {
            Statement sta = conexao.createStatement();

            ResultSet elements = sta.executeQuery("select * from coordenada ");
            while (elements.next()) {
                c = new Coordenada();
                c.setLatitude(elements.getDouble("latitude"));
                c.setLongitude(elements.getDouble("longitude"));
                list.add(c);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public Coordenada getOne(double latitude, double longitude) {
       return  null;
    }

}
