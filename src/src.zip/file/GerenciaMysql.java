/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import conexao.ConexaoMysql;
import coordenada.Coordenada;
import data.MemoryDataBankSolicitacao;
import data.MysqlDao;
import java.util.Date;

public class GerenciaMysql {

    public void InseriMysql() {

        CoordenadaFile file = new CoordenadaFile();
        MemoryDataBankSolicitacao mdb = new MemoryDataBankSolicitacao();

        file.LerArquivo("/home/ton/NetBeansProjects/Experimento_DB/Coordenadas/1.txt", mdb);
        ConexaoMysql conex = new ConexaoMysql();

        Chronometer.start();

        MysqlDao myDao = new MysqlDao(conex.abrirConexao());
        for (Coordenada c : mdb.list()) {
            myDao.save(c);
            Chronometer.stop();
        } 
        System.out.println(Chronometer.elapsedTime() + " milisseconds to write operation in MySQL.");

    }

    public void LeMysql() {
        ConexaoMysql conex = new ConexaoMysql();

        MysqlDao myDao = new MysqlDao(conex.abrirConexao());
        Chronometer.start();
        // System.out.println("Listando" + myDao.list());
        Chronometer.stop();
        System.out.println(Chronometer.elapsedTime() + " milisseconds to read operation in MySQL.");
    }

}
