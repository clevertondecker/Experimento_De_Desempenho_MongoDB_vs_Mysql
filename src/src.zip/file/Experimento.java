/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import conexao.ConexaoMongo;
import conexao.ConexaoMysql;
import coordenada.Coordenada;
import data.MemoryDataBankSolicitacao;
import data.MongoDao;
import data.MysqlDao;
import java.util.Date;
import java.util.Random;

public class Experimento {

    CoordenadaFile file = new CoordenadaFile();
    MemoryDataBankSolicitacao mdb = new MemoryDataBankSolicitacao();
    
    // MongoDB
    MongoDao mDao = new MongoDao();
    ConexaoMongo cxMongo = new ConexaoMongo();

    // Mysql
    ConexaoMysql cxSql = new ConexaoMysql();
    
    public Experimento() {
       file.LerArquivo("/home/ton/NetBeansProjects/Experimento_DB/Coordenadas/1.txt", mdb);
      // System.out.println(mdb.list());
    }
    
    // MongoDB
    public void InserirMongo() {
        Chronometer.start();
        for (Coordenada c : mdb.list()) {
            mDao.save(c);
            Chronometer.stop();
        }
        System.out.println(Chronometer.elapsedTime() + " milisseconds to write operation in MongoDB");

    }
    
    public void BuscarListMongo(){
        mDao.list();
    }
    
    public Coordenada ObterIndexRadom(){
        Random gerador = new Random();
		
	int index = gerador.nextInt(mdb.list().size());
        
       return mdb.list().get(index);
    }
    
    public void BuscarMongo(double latitude, double longitude){
	
        Chronometer.start();
        mDao.getOne(latitude, longitude);
        Chronometer.stop();
        
        System.out.println(Chronometer.elapsedTime() + " milisseconds to write operation in MongoDB");
    }

    // MySQL
    public void InserirMysql() {

        MysqlDao myDao = new MysqlDao(cxSql.abrirConexao());
        
        Chronometer.start();

        for (Coordenada c : mdb.list()) {
            myDao.save(c);
            Chronometer.stop();
        }
        
        System.out.println(Chronometer.elapsedTime() + " milisseconds to write operation in MySQL.");

    }

    public void BuscarLisMysql() {
     
        MysqlDao myDao = new MysqlDao(cxSql.abrirConexao());
        Chronometer.start();
        myDao.list();
        Chronometer.stop();
        System.out.println(Chronometer.elapsedTime() + " milisseconds to read operation in MySQL.");
    }
    
    public void BuscarMysql(){
        
    }
}
